import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cookieParser from 'cookie-parser';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(cookieParser());
app.set('view engine', 'ejs');


// MongoDB connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB', err));

  // Create HTTP server
const server = http.createServer(app);  // Pass `app` to the HTTP server

// Initialize Socket.IO server
const io = new SocketIOServer(server);


// Import routes
import userRoutes from './routes/userRoutes.js';
import productRoutes from './routes/productRoutes.js';
import cartRoutes from './routes/cartRoutes.js';



// Use routes
app.use('/users', userRoutes);
app.use('/products', productRoutes);
app.use('/cart', (req, res, next) => {
  req.io = io; // Attach `io` to the request object
  next();
}, cartRoutes);

app.get('/', (req, res) => res.render('home'));



io.on('connection', (socket) => {
  console.log('A user connected');

});

server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
