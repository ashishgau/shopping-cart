import express from 'express';
import { verifyToken } from '../middleware/auth.js';
import { getAllProducts } from '../controllers/productController.js';

const router = express.Router();

// Get all products
router.get('/', verifyToken, getAllProducts);

export default router;
