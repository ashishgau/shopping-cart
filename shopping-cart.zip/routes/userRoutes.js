import express from 'express';
import { getRegisterPage, postRegisterRequest, getLoginPage, postLoginRequest, getLogout} from '../controllers/authController.js';

const router = express.Router();



router.get('/register', getRegisterPage);
router.post('/register', postRegisterRequest);
router.get('/login', getLoginPage);
router.post('/login', postLoginRequest);
router.get('/logout', getLogout);



export default router;
