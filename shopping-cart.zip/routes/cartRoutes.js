import express from 'express';
import { verifyToken } from '../middleware/auth.js';
import { addToCart, updateCartItemQuantity, removeFromCart, viewCart } from '../controllers/cartController.js';

const router = express.Router();

// Add to cart
router.post('/add', verifyToken, addToCart);

// Update cart item quantity
router.post('/update', verifyToken, updateCartItemQuantity);

// Remove from cart
router.post('/remove', verifyToken, removeFromCart);

// View cart
router.get('/', verifyToken, viewCart);

export default router;
