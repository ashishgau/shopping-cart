import Cart from '../models/Cart.js';

export const addToCart = async (req, res) => {
  try {
    let cart = await Cart.findOne({ userId: req.userId }) || new Cart({ userId: req.userId, items: [] });
    
    const itemIndex = cart.items.findIndex(item => item.productId.toString() === req.body.productId);
    
    if (itemIndex > -1) {
      cart.items[itemIndex].quantity += 1;
    } else {
      cart.items.push({ productId: req.body.productId, quantity: 1 });
    }
    
    await cart.save();
    
    // Populate the cart with product details
    cart = await Cart.findOne({ userId: req.userId }).populate('items.productId');
    console.log(cart);
    
    // Emit the cart update to the specific user
    req.io.emit('cartUpdated', { userId: req.userId, cart });

    res.redirect('/cart');
  } catch (error) {
    console.error('Error adding to cart:', error);
    res.status(500).send('Error adding to cart');
  }
};

export const updateCartItemQuantity = async (req, res) => {
  try {
    let cart = await Cart.findOne({ userId: req.userId });
    const itemIndex = cart.items.findIndex(item => item.productId.toString() === req.body.productId);
    
    if (itemIndex > -1) {
      cart.items[itemIndex].quantity += req.body.quantity;
      if (cart.items[itemIndex].quantity <= 0) {
        cart.items.splice(itemIndex, 1);
      }
      await cart.save();

      // Populate the cart with product details
      cart = await Cart.findOne({ userId: req.userId }).populate('items.productId');
      
      // Emit the cart update to the specific user
      req.io.emit('cartUpdated', { userId: req.userId, cart });
      
      res.status(200).send('Cart updated');
    } else {
      res.status(404).send('Item not found in cart');
    }
  } catch (error) {
    console.error('Error updating cart:', error);
    res.status(500).send('Error updating cart');
  }
};

export const removeFromCart = async (req, res) => {
  try {
    let cart = await Cart.findOne({ userId: req.userId });
    
    cart.items = cart.items.filter(item => item.productId.toString() !== req.body.productId);
    await cart.save();

    // Populate the cart with product details
    cart = await Cart.findOne({ userId: req.userId }).populate('items.productId');
    
    // Emit the cart update to the specific user
    req.io.emit('cartUpdated', { userId: req.userId, cart });
    
    res.status(200).send('Item removed from cart');
  } catch (error) {
    console.error('Error removing from cart:', error);
    res.status(500).send('Error removing from cart');
  }
};

export const viewCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.userId }).populate('items.productId');
    res.render('cart', { cart, userId: req.userId });
  } catch (error) {
    res.status(500).send('Error fetching cart');
  }
};
