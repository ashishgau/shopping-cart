import Product from '../models/Product.js';

export const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find();
    res.render('products', { products, userId: req.userId });
  } catch (error) {
    res.status(500).send('Error fetching products');
  }
};
