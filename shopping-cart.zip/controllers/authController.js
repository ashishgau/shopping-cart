import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js'; // Ensure you have the correct path to your User model


// handle errors
const handleErrors = (err) => {
    console.log(err.message, err.code);
    let errors = { username: '', password: '' }; 
  
    // Duplicate email (email) error
    if (err.code === 11000) {
      errors.username = 'That email is already registered';
      return errors;
    }
  
    // Validation errors
    if (err.message.includes('User validation failed')) {
      Object.values(err.errors).forEach(({ properties }) => {
        errors[properties.path] = properties.message;
      });
    }
  
    return errors;
};

// create json web token
const maxAge = 3 * 24 * 60 * 60;
const createToken = (id) => {
  return jwt.sign({userId: id }, process.env.JWT_SECRET, {
    expiresIn: maxAge
  });
};

// Get register page
const getRegisterPage = async (req, res) => {
  res.render('register');
};

// Post register request
const postRegisterRequest = async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = new User({ username, password});
    await user.save();
    const token = createToken(user._id);
    res.cookie('jwt', token, { httpOnly: true, maxAge: maxAge * 1000 });
    res.status(201).json({ user: user._id });
  }
  catch(err) {
    const errors = handleErrors(err);
    res.status(400).json({ errors });
  }
};


// Get login page
const getLoginPage = async (req, res) => {
  res.render('login');
};

// Post login request
const postLoginRequest = async (req, res) => {
  try {
    const user = await User.findOne({ username: req.body.username });
    if (!user || !await bcrypt.compare(req.body.password, user.password)) {
      return res.status(400).send('Invalid credentials');
    }
  
    //const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);
    // res.json({ token });

    const token = createToken(user._id);
    res.cookie('jwt', token, { httpOnly: true, maxAge: maxAge * 1000 });
    res.status(200).json({ user: user._id });
  } catch (error) {
    res.status(500).send('Error logging in user');
  }
};


const getLogout = (req, res) => {
  res.cookie('jwt', '', { maxAge: 1 });
  res.redirect('/');
}
// Exporting all the functions as a module
export { 
  getRegisterPage, 
  postRegisterRequest, 
  getLoginPage, 
  postLoginRequest ,
  getLogout
};
