## install dependencies
Run `npm install` is to download and install all the dependencies and packages listed in the package.json file into the node_modules directory.

## Development Server

Run `npm start` to start the development server. The application will automatically restart if you change any of the source files.

# Shopping Cart Application

## Description
This is a simple shopping cart application where users can add items to their cart, update item quantities, and remove items. The application includes user authentication, persistent storage with MongoDB, and real-time updates using WebSocket.

## Features
- User Authentication (Registration and Login) with JWT
- Product List Page
- Shopping Cart Management (Add, Update, Remove Items)
- Real-Time Cart Updates
- Persistent Cart Data with MongoDB
- Simple Frontend using EJS Templates

## Installation