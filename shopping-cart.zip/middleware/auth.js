import jwt from "jsonwebtoken";

export function verifyToken(req, res, next) {
  const token = req.cookies.jwt;
  if (token) {
    //console.log(token)
    jwt.verify(token, process.env.JWT_SECRET, (err, decodedToken) => {
      if (err) {
        //console.log(err.message);
        res.redirect("users/login");
      } else {
        console.log(`decode :  ${decodedToken}`);

        req.userId = decodedToken.userId;
        console.log(`user id: ${req.userId}`);
        next();
      }
    });
  } else {
    res.redirect("users/login");
  }
}
